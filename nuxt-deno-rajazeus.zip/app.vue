<template>
  <HeaderLayout/>
  <BodyLayout/>
  <FooterLayout/>
</template>